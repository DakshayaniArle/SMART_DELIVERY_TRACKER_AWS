// const { getDistanceAndTime } = require("./utils/ors");

// exports.handler = async (event) => {
//   const ORS_API_KEY = process.env.ORS_API_KEY;

//   try {
//     const body = JSON.parse(event.body);
//     const { from, to } = body;

//     const { distanceKm, durationMin } = await getDistanceAndTime(from, to, ORS_API_KEY);

//     // You can now store this in DynamoDB or return it to the frontend
//     return {
//       statusCode: 200,
//       body: JSON.stringify({
//         message: "Delivery calculated successfully",
//         from,
//         to,
//         distance: `${distanceKm.toFixed(2)} km`,
//         estimatedTime: `${durationMin.toFixed(2)} minutes`
//       })
//     };
//   } catch (err) {
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: err.message })
//     };
//   }
// };



// const { getDistanceAndDuration } = require("./utils/ors");
// const { getDistanceAndTime } = require("./utils/ors");
// const { v4: uuidv4 } = require("uuid"); // Optional for orderId
// require("dotenv").config();




// exports.handler = async (event) => {
//   const { from, to } = event;
 
//   if (!from || !to) {
//     return {
//       statusCode: 400,
//       body: JSON.stringify({ error: "Both 'from' and 'to' addresses are required." })
//     };
//   }

//   try {
//     const result = await getDistanceAndTime(from, to, process.env.ORS_API_KEY);
//     console.log(result);

//     const response = {
//       orderId: uuidv4(),
//       from,
//       to,
//       distance: result.distanceKm,
//       duration: result.durationMin,
//       status: "Pending",
//       createdAt: new Date().toISOString()
//     };

//     console.log("Generated delivery:", response);

//     return {
//       statusCode: 200,
//       body: JSON.stringify(response)
//     };
//   } catch (err) {
//     console.error("Error:", err);
//     return {
//       statusCode: 500,
//       body: JSON.stringify({ error: "Internal Server Error" })
//     };
//   }
// };


// if (require.main === module) {
//   const testEvent = {
//     from: "Somalingapalem , Elamanchili,Anakapalli , AndhraPradesh",
//     to: "Hyderabad,Telangana"
//   };

//   exports.handler(testEvent, {}).then((res) => {
//     console.log("Lambda output:", res);
//   }).catch((err) => {
//     console.error("Lambda error:", err);
//   });


// const AWS = require('aws-sdk');
// const dynamo = new AWS.DynamoDB.DocumentClient();
// const sns = new AWS.SNS();

// exports.handler = async (event) => {
//   let { orderId, from, to, distance, email } = JSON.parse(event.body);

//   orderId = String(orderId);

//   const now = new Date().toISOString();

//   const item = {
//     orderId,
//     from,
//     to,
//     distance,
//     createdAt: now,
//     status: 'Pending',
//   };

//   // Save to DynamoDB
//   await dynamo.put({
//     TableName: 'Deliveries',
//     Item: item,
//   }).promise();

//   // Send email using SNS
//   const snsMessage = `Your order (${orderId}) from ${from} to ${to} has been placed successfully. Distance: ${distance} km. Status: Pending.`;

//   await sns.publish({
//     Subject: 'Delivery Placed',
//     Message: snsMessage,
//     TopicArn: process.env.SNS_TOPIC_ARN,
//   }).promise();

//   return {
//     statusCode: 200,
//     body: JSON.stringify({ message: 'Delivery added and confirmation mail sent.', delivery: item }),
//   };

// };


const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();

exports.handler = async (event) => {

  console.log("🚀 Lambda started");
  let { from, to, distance, email } = JSON.parse(event.body);

  distance = Number(distance)

  const now = new Date().toISOString();

  // Generate unique orderId (e.g., using timestamp or UUID)
  const orderId = Date.now().toString(); // ✅ Clean ID (e.g., "1720709769000")

  const item = {
    orderId,
    from,
    to,
    distance,
    createdAt: now,
    status: 'Pending',
  };

  console.log(item);

  // Save to DynamoDB
  await dynamo.put({
    TableName: 'Deliveries',
    Item: item,
  }).promise();

  // Send email using SNS
  const snsMessage = `Your order (${orderId}) from ${from} to ${to} has been placed successfully. Distance: ${distance} km. Status: Pending.`;

  await sns.publish({
    Subject: 'Delivery Placed',
    Message: snsMessage,
    TopicArn: process.env.SNS_TOPIC_ARN,
  }).promise();

  // ✅ Return the orderId to the frontend
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Delivery added and confirmation mail sent.',
      orderId: orderId,   // ✅ Return the orderId
    }),
  };
};